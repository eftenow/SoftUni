import { html } from '../../node_modules/lit-html/lit-html.js';
import { getAll } from '../services/itemServices.js';

export const productTemplate = (product) => html`
        <div class="offer">
        <img src="${product.imageUrl}" alt="example1" />
        <p>
            <strong>Title: </strong><span class="title">${product.title}</span>
        </p>
        <p><strong>Salary:</strong><span class="salary">${product.salary}</span></p>
        <a class="details-btn" href="/dashboard/${product._id}">Details</a>
    </div>`

const productsTemplate = (products) => html`
<section id="dashboard">
    <h2>Job Offers</h2>
    ${products.length == 0
        ? html`<h2>No offers yet.</h2>`
            : html`${products.map(p => productTemplate(p))}`}
    </ul>
</section>`

export async function renderDashboard(ctx) {
    const productsList = await getAll();
    const products = productsTemplate(productsList);
    console.log(productsList);
    ctx.render(products);

}