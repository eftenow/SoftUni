import { html } from '../../node_modules/lit-html/lit-html.js';
import { createNew } from '../services/itemServices.js';


const createTemplate = (ctx) => html`
<section id="create">
    <div class="form">
        <h2>Create Offer</h2>
        <form @submit="${(ev) => onCreateHandler(ev, ctx)}" class="create-form">
            <input type="text" name="title" id="job-title" placeholder="Title" />
            <input type="text" name="imageUrl" id="job-logo" placeholder="Company logo url" />
            <input type="text" name="category" id="job-category" placeholder="Category" />
            <textarea id="job-description" name="description" placeholder="Description" rows="4" cols="50"></textarea>
            <textarea id="job-requirements" name="requirements" placeholder="Requirements" rows="4"
                cols="50"></textarea>
            <input type="text" name="salary" id="job-salary" placeholder="Salary" />

            <button type="submit">post</button>
        </form>
    </div>
</section>`

export function renderCreate(ctx) {
    const create = createTemplate(ctx);
    ctx.render(create);
};

async function onCreateHandler(ev, ctx) {
    ev.preventDefault();
    let form = new FormData(ev.target);
    let title = form.get('title');
    let imageUrl = form.get('imageUrl');
    let category = form.get('category');
    let description = form.get('description');
    let requirements = form.get('requirements');
    let salary = form.get('salary');

    let newItem = { title, imageUrl, category, description, requirements, salary };

    if (Object.values(newItem).some((x) => !x)) {
        return alert('All fields must be filled!')
    };

    await createNew(newItem);

    ctx.redirect('/dashboard');

};
