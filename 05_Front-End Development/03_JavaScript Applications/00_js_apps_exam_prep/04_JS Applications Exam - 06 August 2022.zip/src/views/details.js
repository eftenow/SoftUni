import { html } from '../../node_modules/lit-html/lit-html.js';
import { applyReq, deleteItem, getAppliesCount, getDetails, getLikesCount, isAlreadyApplied, likeAlbum, userAlreadyLiked } from '../services/itemServices.js';
import { getUser, getUserId } from '../services/authServices.js';


const detailsTemplate = (item, isOwner, isAuthorized, appliesCount, alreadyApplied, ctx) => html`
      <section id="details">
        <div id="details-wrapper">
          <img id="details-img" src="${item.imageUrl}" alt="example1" />
          <p id="details-title">${item.title}</p>
          <p id="details-category">
            Category: <span id="categories">${item.category}</span>
          </p>
          <p id="details-salary">
            Salary: <span id="salary-number">${item.salary}</span>
          </p>
          <div id="info-wrapper">
            <div id="details-description">
              <h4>Description</h4>
              <span>${item.description}</span>
            </div>
            <div id="details-requirements">
              <h4>Requirements</h4>
              <span>${item.requirements}</span>
            </div>
          </div>
          <p>Applications: <strong id="applications">${appliesCount}</strong></p>
          <div id="action-buttons">
      
            ${isOwner
    ? html`<a href="/edit/${item._id}" id="edit-btn">Edit</a>
            <a @click="${(ev) => onDeleteHandler(ev, ctx)}" href="#" id="delete-btn">Delete</a>`
        : ''}
      
            ${isAuthorized && !isOwner && alreadyApplied == 0
    ? html`<a href="#" id="apply-btn" @click="${(ev) => onApplyHandler(ev, ctx)}">Apply</a>`
        : ''}
          </div>
      
        </div>
      </section>

`


export async function renderDetails(ctx) {
  const currentUser = getUser();
  let curretnUserId = getUserId();
  const itemId = ctx.params.id;

  let promises = Promise.all([
    getDetails(itemId),
    getAppliesCount(itemId),
    isAlreadyApplied(itemId, curretnUserId)
  ])

  const [item, appliesCount, alreadyApplied] = await promises;

  const isAuthorized = currentUser !== null;

  let isOwner = item._ownerId == curretnUserId;

  const details = detailsTemplate(item, isOwner, isAuthorized, appliesCount, alreadyApplied, ctx);

  ctx.render(details);
};




async function onDeleteHandler(ev, ctx) {
  ev.preventDefault();
  const confirmation = confirm("Are you sure you want to delete this item?");

  if (confirmation == true) {
    await deleteItem(ctx.params.id);
    ctx.redirect('/dashboard');
  } else {
    return;
  }
};


async function onApplyHandler(ev, ctx) {
  ev.preventDefault();
  const offerId = ctx.params.id;
  await applyReq(offerId);

  ctx.redirect(`/dashboard/${offerId}`);
}