import { html } from '../../node_modules/lit-html/lit-html.js';
import { getUser } from '../services/authServices.js';
import { getAll, getSearchResult } from '../services/itemServices.js';
import { productTemplate } from './dashboard.js';

const searchTemplate = (searchResults, ctx, isGuest) => html`
<section id="search">
    <h2>Search by Brand</h2>

    <form @submit ="${(ev) => searchItems(ev, ctx)}" class="search-wrapper cf">
        <input id="#search-input" type="text" name="search" placeholder="Search here..." required />
        <button type="submit">Search</button>
    </form>

    <h3>Results:</h3>

    <div id="search-container">

        <ul class="card-wrapper">
        ${searchResults.length === 0
        ? html`<h2>There are no results found.</h2>`
        : html`${searchResults.map(item => productTemplate(item, isGuest))}` }
        </ul>

    </div>
</section>`


export async function renderSearch(ctx) {
    let searchText  = ctx.querystring.split('=')[1];
    const searchResult = searchText === undefined ? [] : await getSearchResult(searchText);
    const isGuest = getUser() === null;
    console.log(isGuest);
    const search = searchTemplate(searchResult, ctx, isGuest);
    ctx.render(search);

};

function searchItems(ev, ctx) {
    ev.preventDefault();
    const form = new FormData(ev.target);
    const searchText = form.get('search').trim();
    ctx.redirect(`/search?query=${searchText}`);
}