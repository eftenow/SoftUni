import { html } from '../../node_modules/lit-html/lit-html.js';
import { editExisting, getDetails } from '../services/itemServices.js';


const editTemplate = (ctx, item) => html`
<section id="edit">
    <div class="form">
        <h2>Edit Offer</h2>
        <form class="edit-form" @submit='${(ev) => editProductHandler(ev, ctx)}'>
            <input value="${item.title}" type="text" name="title" id="job-title" placeholder="Title" />
            <input value="${item.imageUrl}" type="text" name="imageUrl" id="job-logo" placeholder="Company logo url" />
            <input value="${item.category}" type="text" name="category" id="job-category" placeholder="Category" />
            <textarea  id="job-description" name="description" placeholder="Description" rows="4" cols="50">${item.description}</textarea>
            <textarea id="job-requirements" name="requirements" placeholder="Requirements" rows="4"
                cols="50">${item.requirements}</textarea>
            <input value="${item.salary}" type="text" name="salary" id="job-salary" placeholder="Salary" />

            <button type="submit">post</button>
        </form>
    </div>
</section>`

export async function renderEdit(ctx) {
  const id = ctx.params.id;
  const editProduct = await getDetails(id);

  const edit = editTemplate(ctx, editProduct);
  ctx.render(edit);
};

async function editProductHandler(ev, ctx) {
  ev.preventDefault();
  let form = new FormData(ev.target);
  let title = form.get('title');
    let imageUrl = form.get('imageUrl');
    let category = form.get('category');
    let description = form.get('description');
    let requirements = form.get('requirements');
    let salary = form.get('salary');

    let editedItem = { title, imageUrl, category, description, requirements, salary };


  if (Object.values(editedItem).some((x) => !x)) {
    return alert('All fields must be filled!')
  };

  await editExisting(ctx.params.id, editedItem);

  ctx.redirect(`/dashboard/${ctx.params.id}`);
}

