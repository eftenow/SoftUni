import { html } from '../../node_modules/lit-html/lit-html.js';
import { deleteItem, getDetails, getLikesCount, likeAlbum, userAlreadyLiked } from '../services/itemServices.js';
import { getUser, getUserId } from '../services/authServices.js';


const detailsTemplate = (item, isOwner, ctx) => html`

      <section id="details">
        <div id="details-wrapper">
          <p id="details-title">Shoe Details</p>
          <div id="img-wrapper">
            <img src="${item.imageUrl}" alt="example1" />
          </div>
          <div id="info-wrapper">
            <p>Brand: <span id="details-brand">${item.brand}</span></p>
            <p>
              Model: <span id="details-model">${item.model}</span>
            </p>
            <p>Release date: <span id="details-release">${item.release}</span></p>
            <p>Designer: <span id="details-designer">${item.designer}</span></p>
            <p>Value: <span id="details-value">${item.value}</span></p>
          </div>
          <div id="action-buttons">
            ${isOwner
    ? html`
            <a href="/edit/${item._id}" id="edit-btn">Edit</a>
            <a @click="${(ev) => onDeleteHandler(ev, ctx)}" href="#" id="delete-btn">Delete</a>`
    : ""}
          </div>
        </div>
      </section>

`


export async function renderDetails(ctx) {
  const currentUser = getUser();
  let curretnUserId = getUserId();
  const itemId = ctx.params.id;
  const item = await getDetails(itemId);
  const isAuthorized = currentUser !== null;

  let isOwner = item._ownerId == curretnUserId;

  const details = detailsTemplate(item, isOwner, ctx);

  ctx.render(details);
};




async function onDeleteHandler(ev, ctx) {
  ev.preventDefault();
  const confirmation = confirm("Are you sure you want to delete this item?");

  if (confirmation == true) {
    await deleteItem(ctx.params.id);
    ctx.redirect('/dashboard');
  } else {
    return;
  }
};

