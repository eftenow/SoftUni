from project.client import Client
from project.meals.dessert import Dessert
from project.meals.main_dish import MainDish
from project.meals.meal import Meal
from project.meals.starter import Starter


class FoodOrdersApp:
    def __init__(self):
        self.menu = []
        self.clients_list = []
        self.order_id = 0

    def get_client_by_phone_number(self, number):
        return next(filter(lambda client: client.phone_number == number, self.clients_list), None)

    def menu_is_ready(self):
        return len(self.menu) >= 5

    def reset_client_order(self, client):
        client.bill = 0
        client.shopping_cart.clear()


    def register_client(self, client_phone_number: str):
        client_exists = self.get_client_by_phone_number(client_phone_number)
        if client_exists:
            raise Exception("The client has already been registered!")

        client = Client(client_phone_number)
        self.clients_list.append(client)
        return f"Client {client_phone_number} registered successfully."

    def add_meals_to_menu(self, *meals: Meal):
        valid_types = {'Starter': Starter, 'MainDish': MainDish, 'Dessert': Dessert}
        for meal in meals:
            if type(meal).__name__ in valid_types:
                self.menu.append(meal)

    def show_menu(self):
        if not self.menu_is_ready():
            raise Exception("The menu is not ready!")
        res = ''
        for meal in self.menu:
            res += f'{meal.details()}\n'
        return res.strip()

    def add_meals_to_shopping_cart(self, client_phone_number: str, **meal_names_and_quantities):
        if not self.menu_is_ready():
            raise Exception("The menu is not ready!")
        client = self.get_client_by_phone_number(client_phone_number)
        if client is None:
            self.register_client(client_phone_number)
            client = self.get_client_by_phone_number(client_phone_number)
        for meal_name, needed_quantity in meal_names_and_quantities.items():
            meal_object = next(filter(lambda meal: meal.name == meal_name, self.menu), None)
            if not meal_object:
                self.reset_client_order(client)
                raise Exception(f"{meal_name} is not on the menu!")
            available_quantity = meal_object.quantity
            if needed_quantity > available_quantity:
                self.reset_client_order(client)
                raise Exception(f"Not enough quantity of {type(meal_object).__name__}: {meal_name}!")
            meal_object.quantity -= needed_quantity
            ordered_meal = type(meal_object)(meal_name, meal_object.price, needed_quantity)
            client.shopping_cart.append(ordered_meal)
            client.bill += meal_object.price * needed_quantity
        meal_names = ', '.join([meal.name for meal in client.shopping_cart])
        return f"Client {client_phone_number} successfully ordered {meal_names} for {client.bill:.2f}lv."

    def cancel_order(self, client_phone_number):
        client = self.get_client_by_phone_number(client_phone_number)
        if len(client.shopping_cart) < 1:
            raise Exception("There are no ordered meals!")
        for returned_meal in client.shopping_cart:
            returned_meal_name = returned_meal.name
            returned_quantity = returned_meal.quantity
            meal_in_menu = next(filter(lambda meal: meal.name == returned_meal_name, self.menu), None)
            meal_in_menu.quantity += returned_quantity
        self.reset_client_order(client)
        return f"Client {client_phone_number} successfully canceled his order."

    def finish_order(self, client_phone_number):
        client = self.get_client_by_phone_number(client_phone_number)
        if len(client.shopping_cart) < 1:
            raise Exception("There are no ordered meals!")
        self.order_id += 1
        total_paid_money = client.bill
        self.reset_client_order(client)
        return f"Receipt #{self.order_id} with total amount of {total_paid_money:.2f} was successfully paid for {client_phone_number}."

    def __str__(self):
        return f"Food Orders App has {len(self.menu)} meals on the menu and {len(self.clients_list)} clients."

