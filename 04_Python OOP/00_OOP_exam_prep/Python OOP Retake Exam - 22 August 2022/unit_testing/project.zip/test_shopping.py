from project.shopping_cart import ShoppingCart
from unittest import TestCase, main


class ShoppingCartTests(TestCase):
    cart = ShoppingCart('CBA', 50)

    def test_shopping_cart_init(self):
        cart = ShoppingCart('Cba', 50)
        self.assertEqual('Cba', cart.shop_name)
        self.assertEqual(50, cart.budget)
        self.assertEqual({}, cart.products)

    def test_invalid_shop_name_raises(self):
        with self.assertRaises(ValueError) as ex:
            cart = ShoppingCart('cba', 50)
        self.assertEqual("Shop must contain only letters and must start with capital letter!", str(ex.exception))

    def test_adding_too_expensive_product_raises(self):
        cart = ShoppingCart('ABC', 50)
        with self.assertRaises(ValueError) as ex:
            cart.add_to_cart('Kartofi', 100)
        self.assertEqual("Product Kartofi cost too much!", str(ex.exception))
        self.assertEqual({}, cart.products)


    def test_add_product_to_cart(self):
        cart = ShoppingCart('ABC', 50)
        cart.add_to_cart('t1', 20)
        self.assertEqual('t2 product was successfully added to the cart!', cart.add_to_cart('t2', 25))
        self.assertEqual({'t1': 20, 't2': 25}, cart.products)

    def test_remove_item_that_is_not_in_cart_raises(self):
        with self.assertRaises(ValueError) as ex:
            self.cart.remove_from_cart('Banana')
        self.assertEqual("No product with name Banana in the cart!", str(ex.exception))

    def test_remove_item_from_cart(self):
        cart = ShoppingCart('ABC', 50)
        cart.add_to_cart('Banana', 10)
        cart.add_to_cart('Salt', 10)
        result = cart.remove_from_cart('Banana')
        self.assertEqual({"Salt": 10}, cart.products)
        self.assertEqual("Product Banana was successfully removed from the cart!", result)

    def test_add_another_shopping_cart(self):
        first = ShoppingCart('First', 100)
        first.add_to_cart('first', 10)
        second = ShoppingCart('Second', 100)
        second.add_to_cart('second', 10)
        new_cart = first.__add__(second)

        self.assertEqual('FirstSecond', new_cart.shop_name)
        self.assertEqual(200, new_cart.budget)
        self.assertEqual({'first': 10, 'second': 10}, new_cart.products)

    def test_not_enough_money_to_buy_products_raises(self):
        cart = ShoppingCart('ABC', 50)
        cart.add_to_cart('asd', 90)

        with self.assertRaises(ValueError) as ex:
            cart.buy_products()
        self.assertEqual("Not enough money to buy the products! Over budget with 40.00lv!", str(ex.exception))

    def test_buy_products_in_cart(self):
        cart = ShoppingCart('ABC', 100)
        cart.add_to_cart('asd', 90)
        result = cart.buy_products()
        self.assertEqual(f'Products were successfully bought! Total cost: 90.00lv.', result)


if __name__ == '__main__':
    main()