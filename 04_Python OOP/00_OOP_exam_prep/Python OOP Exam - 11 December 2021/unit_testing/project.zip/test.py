from project.team import Team
from unittest import TestCase, main


class TeamTests(TestCase):
    def test_team_init(self):
        team = Team('test')
        self.assertEqual('test', team.name)

    def test_name_setter(self):
        with self.assertRaises(ValueError) as ex:
            team = Team('team5')
        self.assertEqual("Team Name can contain only letters!", str(ex.exception))

    def test_add_member(self):
        team = Team('abc')
        players_to_add = {'test': 10, 'test1': 15, 'test': 10}
        result = team.add_member(**players_to_add)
        self.assertEqual("Successfully added: test, test1", result)
        self.assertEqual({'test': 10, 'test1' :15}, team.members)

    def test_remove_member(self):
        team = Team('abc')
        players_to_add = {'test': 10, 'test1': 15}
        team.add_member(**players_to_add)
        res = team.remove_member('test')
        self.assertEqual("Member test removed", res)
        self.assertEqual({'test1': 15}, team.members)
        res2 = team.remove_member('asd')
        self.assertEqual("Member with name asd does not exist", res2)

    def test_gt_function(self):
        team1 = Team('abc')
        team2 = Team('bca')
        players_to_add = {'test': 10, 'test1': 15}
        team1.add_member(**players_to_add)
        players_to_add = {'test': 10, 'test1': 15, 'gg': 12}
        team2.add_member(**players_to_add)
        res = team1.__gt__(team2)
        self.assertEqual(False, res)
        res2 = team2.__gt__(team1)
        self.assertEqual(True, res2)

    def test_len_method(self):
        team1 = Team('abc')
        players_to_add = {'test': 10, 'test1': 15}
        team1.add_member(**players_to_add)
        res = len(team1)
        self.assertEqual(2, res)

    def test_add_method(self):
        team1 = Team('abc')
        team2 = Team('bca')
        player_first = {'test': 10, 'test1': 15}
        player_second = {'test2': 10, 'test3': 15}
        team1.add_member(**player_first)
        team2.add_member(**player_second)
        result = team1.__add__(team2)

        self.assertEqual('abcbca', result.name)
        self.assertEqual({'test': 10, 'test1': 15, 'test2': 10, 'test3': 15}, result.members)


    def test_str_method(self):
        team = Team('abc')
        player_first = {'a': 10, 'b': 15, 'c' : 15}
        team.add_member(**player_first)
        expected = 'Team name: abc\nMember: b - 15-years old\nMember: c - 15-years old\nMember: a - 10-years old'
        self.assertEqual(expected, str(team))

if __name__ == '__main__':
    main()