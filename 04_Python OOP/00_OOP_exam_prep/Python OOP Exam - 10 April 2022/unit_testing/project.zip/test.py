from project.movie import Movie
from unittest import TestCase, main


class MovieTests(TestCase):
    def test_movie_init(self):
        movie = Movie('test', 1999, 8)
        self.assertEqual('test', movie.name)
        self.assertEqual(1999, movie.year)
        self.assertEqual(8, movie.rating)
        self.assertEqual([], movie.actors)

    def test_name_cannot_be_empty_str_raises(self):
        with self.assertRaises(ValueError) as ex:
            movie = Movie('', 1999, 5)
        self.assertEqual("Name cannot be an empty string!", str(ex.exception))

    def test_invalid_year_raises(self):
        with self.assertRaises(ValueError) as ex:
            movie = Movie("test", 1886, 5)
        self.assertEqual('Year is not valid!', str(ex.exception))

    def test_add_actor(self):
        movie = Movie('test', 1999, 9)
        movie.add_actor('test_actor')
        self.assertEqual(['test_actor'], movie.actors)
        movie.add_actor('testing')
        self.assertEqual(['test_actor', 'testing'], movie.actors)
        res = movie.add_actor('test_actor')
        self.assertEqual("test_actor is already added in the list of actors!", res)
        self.assertEqual(['test_actor', 'testing'], movie.actors)

    def test_gt_method(self):
        movie1 = Movie('test1', 1999, 6)
        movie2 = Movie('test2', 1999, 8)
        result = movie1.__gt__(movie2)
        self.assertEqual('"test2" is better than "test1"', result)
        result = movie2.__gt__(movie1)
        self.assertEqual('"test2" is better than "test1"', result)

    def test_repr(self):
        movie = Movie('asd', 1999, 9)
        movie.add_actor('tester1')
        movie.add_actor('tester2')
        actors = ", ".join(actor for actor in movie.actors)
        expected = f'Name: asd\nYear of Release: 1999\nRating: 9.00\nCast: {actors}'
        self.assertEqual(expected, movie.__repr__())


if __name__== "__main__":
    main()