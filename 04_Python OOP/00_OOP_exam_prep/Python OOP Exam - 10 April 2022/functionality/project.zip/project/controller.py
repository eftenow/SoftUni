from project.player import Player


class Controller:
    def __init__(self):
        self.players = []
        self.supplies = []

    def get_last_supply_of_type(self, supply_type):
        for supply_ind in range(len(self.supplies)-1, 0, -1):
            supply = self.supplies[supply_ind]
            if type(supply).__name__ == supply_type:
                return self.supplies.pop(supply_ind)

    def get_player_by_name(self, player_name):
        return next(filter(lambda player: player.name == player_name, self.players), None)

    def add_player(self, *players):
        players_added = []
        for player in players:
            if not self.get_player_by_name(player.name):
                self.players.append(player)
                players_added.append(player.name)
        return f"Successfully added: {', '.join(players_added)}"

    def add_supply(self, *supplies):
        for supply in supplies:
            self.supplies.append(supply)

    def sustain(self, player_name, sustenance_type):
        if sustenance_type in ['Food', 'Drink']:
            supplies_of_needed_type = [supply for supply in self.supplies if type(supply).__name__ == sustenance_type]
            if not supplies_of_needed_type and sustenance_type == 'Food':
                raise Exception("There are no food supplies left!")
            elif not supplies_of_needed_type and sustenance_type == 'Drink':
                raise Exception("There are no drink supplies left!")
            player = self.get_player_by_name(player_name)
            if not player.need_sustenance:
                return f"{player_name} have enough stamina."
            supply = self.get_last_supply_of_type(sustenance_type)
            if supply.energy + player.stamina > 100:
                player.stamina = 100
            else:
                player.stamina += supply.energy

            return f"{player_name} sustained successfully with {supply.name}."

    def duel(self, first_player_name, second_player_name):
        player1 = self.get_player_by_name(first_player_name)
        player2 = self.get_player_by_name(second_player_name)
        if player1.stamina <= 0 and player2.stamina <= 0:
            return f"Player {player1.name} does not have enough stamina.\nPlayer {player2.name} does not have enough stamina."
        elif player1.stamina <= 0:
            return f"Player {player1.name} does not have enough stamina."
        elif player2.stamina <= 0:
            return f"Player {player2.name} does not have enough stamina."
        players = [p for p in sorted([player1, player2], key=lambda p: p.stamina)]
        for ind, player in enumerate(players):
            enemy = players[(ind+1) % 2]
            dmg = player.stamina / 2
            if enemy.stamina - dmg <= 0:
                enemy.stamina = 0
                return f'Winner: {player.name}'
            else:
                enemy.stamina -= dmg
        winner = [p for p in sorted([player1, player2], key=lambda p: -p.stamina)][0]
        return f'Winner: {winner.name}'

    def next_day(self):
        for player in self.players:
            if player.stamina - player.age * 2 < 0:
                player.stamina = 0
            else:
                player.stamina -= player.age * 2
            self.sustain(player.name, 'Food')
            self.sustain(player.name, 'Drink')

    def __str__(self):
        result = ''
        for player in self.players:
            result += str(player) + '\n'
        for food in self.supplies:
            result += food.details() + '\n'
        return result.strip()
