from project.pet_shop import PetShop
from unittest import TestCase, main


class PetShopTests(TestCase):
    shop = PetShop('shop')

    def test_pet_shop_init(self):
        shop = PetShop('shop')
        self.assertEqual('shop', shop.name)

    def test_add_zero_or_negative_food_raises(self):
        with self.assertRaises(ValueError) as ex:
            self.shop.add_food('test', -1)
        self.assertEqual('Quantity cannot be equal to or less than 0', str(ex.exception))
        with self.assertRaises(ValueError) as ex:
            self.shop.add_food('test', 0)
        self.assertEqual('Quantity cannot be equal to or less than 0', str(ex.exception))

    def test_add_food(self):
        res = self.shop.add_food('test', 100)
        expected = {'test': 100}
        self.assertEqual(expected, self.shop.food)
        self.assertEqual(res, 'Successfully added 100.00 grams of test.')
        self.shop.add_food('test2', 200)
        expected = {'test': 100, 'test2': 200}
        self.assertEqual(expected, self.shop.food)
        self.shop.add_food('test2', 200)
        expected = {'test': 100, 'test2': 400}
        self.assertEqual(expected, self.shop.food)

    def test_add_pet(self):
        res = self.shop.add_pet('Barry')
        self.assertEqual(res, "Successfully added Barry.")
        self.assertEqual(['Barry'], self.shop.pets)
        self.shop.add_pet('Tiara')
        self.assertEqual(['Barry', 'Tiara'], self.shop.pets)

    def test_non_existing_pet_raises(self):
        with self.assertRaises(Exception) as ex:
            self.shop.feed_pet('testt', 'test')
        self.assertEqual("Please insert a valid pet name", str(ex.exception))

    def test_non_existing_food(self):
        self.shop.pets = ['tigr']
        result = self.shop.feed_pet('pedigreee', 'tigr')
        self.assertEqual(result, 'You do not have pedigreee')

    def test_feed_pet(self):
        self.shop.pets = ['tigr']
        self.shop.food = {"pedigree": 50}
        res = self.shop.feed_pet('pedigree', 'tigr')
        self.assertEqual(res, "Adding food...")
        self.assertEqual({'pedigree': 1050}, self.shop.food)
        res = self.shop.feed_pet('pedigree', 'tigr')
        self.assertEqual("tigr was successfully fed", res)
        self.assertEqual({'pedigree': 950}, self.shop.food)

    def test_repr(self):
        my_shop = PetShop('test')
        my_shop.add_pet('dog')
        my_shop.add_pet('cat')
        self.assertEqual("Shop test:\nPets: dog, cat", repr(my_shop))

if __name__ == '__main__':
    main()