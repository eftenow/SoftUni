from unittest import TestCase, main
from project.factory.factory import Factory
from project.factory.paint_factory import PaintFactory


class FactoryTests(TestCase):
    def test_initialize_factory_raises(self):
        with self.assertRaises(Exception) as ex:
            fact = Factory('asd', 5)
        self.assertEqual("Can't instantiate abstract class Factory with abstract methods __init__, add_ingredient, remove_ingredient", str(ex.exception))

    def test_init_paint_factory(self):
        fact = PaintFactory('sad', 10)
        self.assertEqual('sad', fact.name)
        self.assertEqual(10, fact.capacity)

    def test_add_invalid_ingredient_raises(self):
        fact = PaintFactory('sad', 10)
        with self.assertRaises(TypeError) as ex:
            fact.add_ingredient('black', 1)
        self.assertEqual("Ingredient of type black not allowed in PaintFactory", str(ex.exception))

    def test_add_ingredient(self):
        fact = PaintFactory('sad', 4)
        fact.add_ingredient('red', 1)
        self.assertEqual({'red': 1}, fact.ingredients)
        fact.add_ingredient('blue', 1)
        self.assertEqual({'red': 1, 'blue': 1}, fact.ingredients)
        fact.add_ingredient('blue', 2)
        self.assertEqual({'red': 1, 'blue': 3}, fact.ingredients)
        with self.assertRaises(ValueError) as ex:
            fact.add_ingredient('blue', 1)
        self.assertEqual("Not enough space in factory", str(ex.exception))

    def test_remove_non_existing_raises(self):
        fact = PaintFactory('sad', 4)
        fact.add_ingredient('red', 1)

        with self.assertRaises(KeyError) as ex:
            fact.remove_ingredient('yellow', 1)
        self.assertEqual("'No such ingredient in the factory'", str(ex.exception))
        self.assertEqual({'red': 1}, fact.ingredients)

    def test_remove(self):
        fact = PaintFactory('sad', 4)
        fact.add_ingredient('red', 1)
        self.assertEqual({'red': 1}, fact.ingredients)
        fact.add_ingredient('blue', 3)
        self.assertEqual({'red': 1, 'blue': 3}, fact.ingredients)
        fact.remove_ingredient('blue', 3)
        self.assertEqual({'red': 1, 'blue': 0}, fact.ingredients)
        with self.assertRaises(ValueError) as ex:
            fact.remove_ingredient('blue', 1)
        self.assertEqual("Ingredients quantity cannot be less than zero", str(ex.exception))

    def test_products(self):
        fact = PaintFactory('sad', 4)
        fact.add_ingredient('red', 1)
        self.assertEqual({'red': 1}, fact.ingredients)
        self.assertEqual({'red': 1}, fact.products)

    def test_can_add(self):
        fact = PaintFactory('sad', 2)
        fact.add_ingredient('red', 1)
        self.assertEqual(True, fact.can_add(1))
        self.assertEqual(False, fact.can_add(2))

    def test_repr_method(self):
        fact = PaintFactory('sadsa', 3)
        fact.add_ingredient('red', 1)
        fact.add_ingredient('green', 2)
        expected = f'Factory name: sadsa with capacity 3.\nred: 1\ngreen: 2\n'
        self.assertEqual(expected, fact.__repr__())


if __name__ == '__main__':
    main()