from project.student_report_card import StudentReportCard
from unittest import TestCase, main


class StudentReportCardTests(TestCase):
    def test_card_init(self):
        card = StudentReportCard('test', 1)
        self.assertEqual('test', card.student_name)
        self.assertEqual(1, card.school_year)
        card.school_year = 12
        self.assertEqual(12, card.school_year)

    def test_invalid_init(self):
        with self.assertRaises(ValueError) as ex:
            card = StudentReportCard('test', 0)
        self.assertEqual("School Year must be between 1 and 12!", str(ex.exception))

        with self.assertRaises(ValueError) as ex:
            card = StudentReportCard('test', -1)
        self.assertEqual("School Year must be between 1 and 12!", str(ex.exception))

        with self.assertRaises(ValueError) as ex:
            card = StudentReportCard('test', 13)
        self.assertEqual("School Year must be between 1 and 12!", str(ex.exception))

        with self.assertRaises(ValueError) as ex:
            card = StudentReportCard('', 2)
        self.assertEqual("Student Name cannot be an empty string!", str(ex.exception))

    def test_add_grade(self):
        card = StudentReportCard('test', 1)
        card.add_grade('math', 5)
        card.add_grade('bio', 6)
        self.assertEqual({'math': [5], 'bio': [6]}, card.grades_by_subject)
        card.add_grade('bio', 4)
        self.assertEqual({'math': [5], 'bio': [6, 4]}, card.grades_by_subject)

    def test_average_grade_by_subj(self):
        card = StudentReportCard('test', 1)
        card.add_grade('math', 5)
        card.add_grade('bio', 3)
        card.add_grade('bio', 4)
        self.assertEqual({'math': [5], 'bio': [3, 4]}, card.grades_by_subject)
        self.assertEqual('math: 5.00\nbio: 3.50', card.average_grade_by_subject())

    def test_average_grade(self):
        card = StudentReportCard('test', 1)
        card.add_grade('math', 5)
        card.add_grade('bio', 3)
        card.add_grade('bio', 4)
        avg_grade = (5+3+4) / 3
        self.assertEqual(f"Average Grade: {avg_grade:.2f}", card.average_grade_for_all_subjects())

    def test_repr(self):
        card = StudentReportCard('test', 1)
        card.add_grade('math', 5)
        card.add_grade('bio', 3)
        card.add_grade('bio', 4)
        avg_grade = (5 + 3 + 4) / 3
        expected = f'Name: test\nYear: 1\n----------\nmath: 5.00\nbio: 3.50\n----------\nAverage Grade: {avg_grade:.2f}'
        self.assertEqual(expected, card.__repr__())

if __name__ == '__main__':
    main()