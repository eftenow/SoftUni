from project.rooms.room import Room


class AloneOld(Room):
    def __init__(self, family_name, pension):
        super().__init__(family_name, pension, 1)
        self.family_name = family_name
        self.members_count = 1
        self.budget = pension
        self.room_cost = 10
        self.appliances = []
        self.calculate_expenses(self.appliances)