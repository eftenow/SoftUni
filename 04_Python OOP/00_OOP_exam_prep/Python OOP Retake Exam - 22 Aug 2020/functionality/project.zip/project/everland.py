class Everland:
    def __init__(self):
        self.rooms = []

    def add_room(self, room):
        if room not in self.rooms:
            self.rooms.append(room)

    def get_monthly_consumptions(self):
        total = 0
        for room in self.rooms:
            total += room.expenses + room.room_cost
        return f"Monthly consumptions: {total:.2f}$."

    def pay(self):
        res = ''
        for room in self.rooms:
            total_expenses = room.expenses + room.room_cost
            if room.budget < total_expenses:
                self.rooms.remove(room)
                res += f"{room.family_name} does not have enough budget and must leave the hotel.\n"
            else:
                room.budget -= total_expenses
                res += f"{room.family_name} paid {total_expenses:.2f}$ and have {room.budget:.2f}$ left.\n"
        return res.strip()

    def status(self):
        res = f'Total population: {sum([r.members_count for r in self.rooms])}\n'
        for room in self.rooms:
            res += f'{room.family_name} with {room.members_count} members. Budget: {room.budget:.2f}$,' \
                   f' Expenses: {room.expenses:.2f}$\n'
            for ind, child in enumerate(room.children):
                res += f"--- Child {ind+1} monthly cost: {child.get_monthly_expense():.2f}$\n"
            appliances_cost = sum([a.get_monthly_expense() for a in room.appliances])
            res += f'--- Appliances monthly cost: {appliances_cost:.2f}$\n'
        return res.strip()



