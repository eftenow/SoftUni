from project.astronaut.astronaut_repository import AstronautRepository
from project.astronaut.biologist import Biologist
from project.astronaut.geodesist import Geodesist
from project.astronaut.meteorologist import Meteorologist
from project.planet.planet import Planet
from project.planet.planet_repository import PlanetRepository


class SpaceStation:
    completed = 0
    failed = 0

    def __init__(self):
        self.planet_repository = PlanetRepository()
        self.astronaut_repository = AstronautRepository()

    def add_astronaut(self, astronaut_type, name):
        astronaut_exists = AstronautRepository.find_by_name(self.astronaut_repository, name)
        if astronaut_exists:
            return f"{name} is already added."
        valid_types = {'Biologist': Biologist, "Geodesist": Geodesist, 'Meteorologist': Meteorologist}
        if astronaut_type not in valid_types:
            raise Exception("Astronaut type is not valid!")
        new_astr = valid_types[astronaut_type](name)
        self.astronaut_repository.add(new_astr)
        return f"Successfully added {astronaut_type}: {name}."

    def add_planet(self, name, items):
        planet_exists = PlanetRepository.find_by_name(self.planet_repository, name)
        if planet_exists:
            return f"{name} is already added."
        new_planet = Planet(name)
        self.planet_repository.add(new_planet)
        items = items.split(', ')
        new_planet.items = items
        return f"Successfully added Planet: {name}."

    def retire_astronaut(self, name):
        astronaut = self.astronaut_repository.find_by_name(name)
        if not astronaut:
            raise Exception(f"Astronaut {name} doesn't exist!")
        self.astronaut_repository.remove(astronaut)
        return f"Astronaut {name} was retired!"

    def recharge_oxygen(self):
        for astronaut in self.astronaut_repository.astronauts:
            astronaut.oxygen += 10

    def send_on_mission(self, planet_name: str):
        planet = self.planet_repository.find_by_name(planet_name)
        if not planet:
            raise Exception("Invalid planet name!")
        suitable_astronauts = [a for a in sorted(self.astronaut_repository.astronauts, key=lambda astro: -astro.oxygen) if a.oxygen > 30]
        if not suitable_astronauts:
            self.failed += 1
            raise Exception("You need at least one astronaut to explore the planet!")
        if len(suitable_astronauts) > 5:
            suitable_astronauts = suitable_astronauts[:5]

        for ind, astronaut in enumerate(suitable_astronauts):

            while astronaut.oxygen > 0 and len(planet.items) > 0:
                astronaut.backpack.append(planet.items.pop())
                astronaut.breathe()
            if len(planet.items) == 0:
                self.completed += 1
                return f"Planet: {planet_name} was explored. {ind + 1} astronauts participated in collecting items."
        if len(planet.items) > 0:
            self.failed += 1
            return "Mission is not completed."

    def report(self):
        result = f"{self.completed} successful missions!\n"
        result += f"{self.failed} missions were not completed!\n"
        result += f"Astronauts' info:\n"
        for astronaut in self.astronaut_repository.astronauts:
            result += f'Name: {astronaut.name}\n'
            result += f'Oxygen: {astronaut.oxygen}\n'
            backpack_items = [i for i in astronaut.backpack]
            if not backpack_items:
                backpack_items = ['none']
            result += f"Backpack items: {', '.join(backpack_items)}\n"
        return result




station = SpaceStation()
print(station.add_astronaut('Biologist', 'Ben'))
print(station.add_astronaut('Biologist', 'Sall'))
print(station.add_astronaut('Biologist', 'Ball'))
print(station.add_astronaut('Meteorologist', 'Ken'))
print(station.add_astronaut('Meteorologist', 'Len'))
print(station.add_astronaut('Geodesist', 'Sen'))
print(station.add_astronaut('Geodesist', 'test'))
print(station.add_planet('Mars', 'apples, bananas, water, gas, wood, glass, test'))
print(station.retire_astronaut('test'))
print(station.send_on_mission('Mars'))
print(station.recharge_oxygen())
print(station.report())


