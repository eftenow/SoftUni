from project.astronaut.astronaut import Astronaut


class Geodesist(Astronaut):
    OXYGEN_PER_BREATH = 10

    def __init__(self, name):
        super().__init__(name, 50)