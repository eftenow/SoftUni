from project.library import Library
from unittest import TestCase, main


class LibraryTests(TestCase):
    def test_library_init(self):
        lib = Library('library')
        self.assertEqual('library', lib.name)
        self.assertEqual({}, lib.books_by_authors)
        self.assertEqual({}, lib.readers)

    def test_library_name_setter(self):
        with self.assertRaises(ValueError) as ex:
            lib = Library('')
        self.assertEqual("Name cannot be empty string!", str(ex.exception))

    def test_add_book_adds_new_author_new_book(self):
        lib = Library('lib')
        self.assertEqual({}, lib.books_by_authors)
        lib.add_book('Vazov', 'Pod igoto')
        lib.add_book('Botev', 'Elegia')
        self.assertEqual({'Vazov': ["Pod igoto"], 'Botev': ['Elegia']}, lib.books_by_authors)

    def test_add_book_adds_new_book_to_existing_author(self):
        lib = Library('lib')
        lib.books_by_authors = {'Vazov': ["Pod igoto"]}
        lib.add_book('Vazov', 'test1')
        lib.add_book('Vazov', 'test2')
        self.assertEqual({'Vazov': ["Pod igoto", 'test1', "test2"]}, lib.books_by_authors)

    def test_add_new_reader(self):
        lib = Library('lib')
        self.assertEqual({}, lib.readers)
        lib.add_reader('tester1')
        lib.add_reader('tester2')
        self.assertEqual({'tester1':[], "tester2":[]}, lib.readers)

    def test_add_existing_reader_returns_message(self):
        lib = Library('lib')
        lib.readers = {'tester1':[], "tester2":[]}
        result = lib.add_reader('tester1')
        self.assertEqual("tester1 is already registered in the lib library.", result)

    def test_rent_book_if_reader_doesnt_exist_raises(self):
        lib = Library('lib')
        lib.add_reader('test')
        result = lib.rent_book('test1', 'test', 'test')
        self.assertEqual("test1 is not registered in the lib Library.", result)

    def test_rent_book_if_author_doesnt_exist_raises(self):
        lib = Library('lib')
        lib.add_reader('test')
        result = lib.rent_book('test', 'Elin Pelin', 'test')
        self.assertEqual("lib Library does not have any Elin Pelin's books.", result)

    def test_rent_book_if_book_doesnt_exist_raises(self):
        lib = Library('lib')
        lib.add_reader('test')
        lib.add_book('Elin Pelin', 'test1')
        result = lib.rent_book('test', 'Elin Pelin', 'test')
        self.assertEqual("""lib Library does not have Elin Pelin's "test".""", result)

    def test_rent_book_gives_book_to_reader_and_removes_from_lib(self):
        lib = Library('lib')
        lib.add_reader('test')
        lib.add_book('Elin Pelin', 'test1')
        lib.add_book('Elin Pelin', 'book')
        lib.add_book('Elin Pelin', 'test3')
        lib.rent_book('test', 'Elin Pelin', "book")
        self.assertEqual({'test': [{'Elin Pelin': 'book'}]}, lib.readers)
        self.assertEqual({'Elin Pelin': ['test1', 'test3']} ,lib.books_by_authors)
        lib.rent_book('test', 'Elin Pelin', 'test1')
        self.assertEqual({'test': [{'Elin Pelin': 'book'}, {'Elin Pelin': 'test1'}]}, lib.readers)

if __name__ == "__main__":
    main()