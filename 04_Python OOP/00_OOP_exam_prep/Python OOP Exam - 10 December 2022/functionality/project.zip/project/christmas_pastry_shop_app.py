from project.booths.open_booth import OpenBooth
from project.booths.private_booth import PrivateBooth
from project.delicacies.gingerbread import Gingerbread
from project.delicacies.stolen import Stolen


class ChristmasPastryShopApp:
    def __init__(self):
        self.booths = []
        self.delicacies = []
        self.income = 0

    def get_delicacy_by_name(self, delicacy_name):
        return next(filter(lambda delicacy: delicacy.name == delicacy_name, self.delicacies), None)

    def get_booth_by_number(self, booth_number):
        return next(filter(lambda booth: booth.booth_number == booth_number, self.booths), None)

    def add_delicacy(self, type_delicacy: str, name: str, price: float):
        delicacy_exists = self.get_delicacy_by_name(name)
        if delicacy_exists:
            raise Exception(f"{name} already exists!")
        valid_types = {"Gingerbread": Gingerbread, 'Stolen': Stolen}
        if type_delicacy not in valid_types:
            raise Exception(f"{type_delicacy} is not on our delicacy menu!")
        delicacy = valid_types[type_delicacy](name, price)
        self.delicacies.append(delicacy)
        return f"Added delicacy {name} - {type_delicacy} to the pastry shop."

    def add_booth(self, type_booth: str, booth_number: int, capacity: int):
        booth_exists = self.get_booth_by_number(booth_number)
        if booth_exists:
            raise Exception(f"Booth number {booth_number} already exists!")
        valid_types = {'Open Booth': OpenBooth, 'Private Booth': PrivateBooth}
        if type_booth not in valid_types:
            raise Exception(f"{type_booth} is not a valid booth!")
        booth = valid_types[type_booth](booth_number, capacity)
        self.booths.append(booth)
        return f"Added booth number {booth_number} in the pastry shop."

    def reserve_booth(self, number_of_people: int):
        free_booths = [booth for booth in self.booths if booth.capacity >= number_of_people and not booth.is_reserved]
        if not free_booths:
            raise Exception(f"No available booth for {number_of_people} people!")
        booth = free_booths[0]
        booth.reserve(number_of_people)
        return f"Booth {booth.booth_number} has been reserved for {number_of_people} people."

    def order_delicacy(self, booth_number: int, delicacy_name: str):
        booth = self.get_booth_by_number(booth_number)
        delicacy = self.get_delicacy_by_name(delicacy_name)
        if not booth:
            raise Exception(f"Could not find booth {booth_number}!")
        if not delicacy:
            raise Exception(f"No {delicacy_name} in the pastry shop!")
        booth.delicacy_orders.append(delicacy)
        return f"Booth {booth_number} ordered {delicacy_name}."

    def leave_booth(self, booth_number: int):
        booth = self.get_booth_by_number(booth_number)
        reservation_price = booth.price_for_reservation
        orders_price = sum([delicacy.price for delicacy in booth.delicacy_orders])
        bill = reservation_price + orders_price
        self.income += bill
        booth.is_reserved = False
        booth.price_for_reservation = 0
        booth.delicacy_orders = []
        result = f"Booth {booth_number}:\n"
        result += f"Bill: {bill:.2f}lv.\n"
        return result.strip()

    def get_income(self):
        return f"Income: {self.income:.2f}lv."





shop = ChristmasPastryShopApp()
print(shop.add_delicacy("Gingerbread", "Gingy", 5.20))
print(shop.delicacies[0].details())
print(shop.add_booth("Open Booth", 1, 30))
print(shop.add_booth("Private Booth", 10, 5))
print(shop.reserve_booth(30))
print(shop.order_delicacy(1, "Gingy"))
print(shop.leave_booth(1))
print(shop.reserve_booth(5))
print(shop.order_delicacy(1, "Gingy"))
print(shop.order_delicacy(1, "Gingy"))
print(shop.order_delicacy(1, "Gingy"))
print(shop.leave_booth(1))
print(shop.get_income())

