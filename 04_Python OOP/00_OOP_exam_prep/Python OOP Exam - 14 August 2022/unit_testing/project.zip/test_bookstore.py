from project.bookstore import Bookstore
from unittest import TestCase, main


class BookstoreTests(TestCase):
    def test_bookstore_init(self):
        store = Bookstore(5)
        self.assertEqual(5, store.books_limit)
        self.assertEqual({}, store.availability_in_store_by_book_titles)
        self.assertEqual(0, store.total_sold_books)

    def test_store_limit_zero_or_below_raises(self):
        with self.assertRaises(ValueError) as ex:
            store = Bookstore(0)
        self.assertEqual("Books limit of 0 is not valid", str(ex.exception))
        with self.assertRaises(ValueError) as ex:
            store = Bookstore(-5)
        self.assertEqual("Books limit of -5 is not valid", str(ex.exception))

    def test_len_returns_number_of_books_in_store(self):
        store = Bookstore(5)
        store.availability_in_store_by_book_titles = {'test': 2, 'test1': 3, 'test2': 3}
        self.assertEqual(8, len(store))

    def test_receive_books_after_books_limit_raises(self):
        store = Bookstore(5)
        store.availability_in_store_by_book_titles = {'test': 1, 'test1': 1, 'test2': 2}
        with self.assertRaises(Exception) as ex:
            store.receive_book('testing', 2)
        self.assertEqual("Books limit is reached. Cannot receive more books!", str(ex.exception))

    def test_receive_book_adds_new_book(self):
        store = Bookstore(10)
        store.availability_in_store_by_book_titles = {'test': 1, 'test1': 1, 'test2': 2}
        store.receive_book('testing', 2)
        self.assertEqual({'test': 1, 'test1': 1, 'test2': 2, 'testing': 2}, store.availability_in_store_by_book_titles)

    def test_receive_book_adds_more_copies_to_existing_book(self):
        store = Bookstore(10)
        store.availability_in_store_by_book_titles = {'test': 2, 'test1': 1, 'test2': 2}
        result = store.receive_book('test', 5)
        self.assertEqual("7 copies of test are available in the bookstore.", result)

    def test_sell_non_existing_book_raises(self):
        store = Bookstore(10)
        store.availability_in_store_by_book_titles = {'test': 2, 'test1': 1, 'test2': 2}
        with self.assertRaises(Exception) as ex:
            store.sell_book('asd', 5)
        self.assertEqual("Book asd doesn't exist!", str(ex.exception))

    def test_sell_book_invalid_quantity(self):
        store = Bookstore(10)
        store.availability_in_store_by_book_titles = {'test': 2, 'test1': 1, 'test2': 2}
        with self.assertRaises(Exception) as ex:
            store.sell_book('test', 3)

        self.assertEqual("test has not enough copies to sell. Left: 2", str(ex.exception))

    def test_sell_book_valid_quantity(self):
        store = Bookstore(10)
        store.availability_in_store_by_book_titles = {'test': 2, 'test1': 1, 'test2': 2}
        result = store.sell_book('test', 2)
        self.assertEqual("Sold 2 copies of test", result)

    def test_library_str_method(self):
        store = Bookstore(10)
        store.availability_in_store_by_book_titles = {'test': 2, 'test1': 1, 'test2': 2, "testing": 3}
        store.sell_book('test', 2)
        store.sell_book('test1', 1)
        result = "Total sold books: 3\nCurrent availability: 5\n"
        result += " - test: 0 copies\n"
        result += " - test1: 0 copies\n"
        result += " - test2: 2 copies\n"
        result += " - testing: 3 copies\n"
        self.assertEqual(result.strip(), str(store))


if __name__ == '__main__':
    main()