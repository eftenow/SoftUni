from project.horse_race import HorseRace
from project.horse_specification.appaloosa import Appaloosa
from project.horse_specification.thoroughbred import Thoroughbred
from project.jockey import Jockey


class HorseRaceApp:
    def __init__(self):
        self.horses = []
        self.jockeys = []
        self.horse_races = []

    def get_jockey_by_name(self, jockey_name):
        return next(filter(lambda jockey: jockey.name == jockey_name, self.jockeys), None)

    def get_race_by_type(self, race_type):
        return next(filter(lambda race: race.race_type == race_type, self.horse_races), None)

    def add_horse(self, horse_type, horse_name, horse_speed):
        valid_types = {"Appaloosa": Appaloosa, "Thoroughbred": Thoroughbred}
        if horse_type in valid_types:
            if horse_name in [horse.name for horse in self.horses]:
                raise Exception(f"Horse {horse_name} has been already added!")
            new_horse = valid_types[horse_type](horse_name, horse_speed)
            self.horses.append(new_horse)
            return f"{horse_type} horse {horse_name} is added."

    def add_jockey(self, jockey_name, age):
        if jockey_name in [jockey.name for jockey in self.jockeys]:
            raise Exception(f"Jockey {jockey_name} has been already added!")
        new_jockey = Jockey(jockey_name, age)
        self.jockeys.append(new_jockey)
        return f"Jockey {jockey_name} is added."

    def create_horse_race(self, race_type):
        if race_type in [race.race_type for race in self.horse_races]:
            raise Exception(f"Race {race_type} has been already created!")
        new_race = HorseRace(race_type)
        self.horse_races.append(new_race)
        return f"Race {race_type} is created."

    def add_horse_to_jockey(self, jockey_name, horse_type):
        jockey = self.get_jockey_by_name(jockey_name)
        if not jockey:
            raise Exception(f"Jockey {jockey_name} could not be found!")
        available_horses = [horse for horse in self.horses if type(horse).__name__ == horse_type and not horse.is_taken]
        if not available_horses:
            raise Exception(f"Horse breed {horse_type} could not be found!")
        if jockey.horse is not None:
            return f"Jockey {jockey_name} already has a horse."
        current_horse = available_horses[-1]
        current_horse.is_taken = True
        jockey.horse = current_horse
        return f"Jockey {jockey_name} will ride the horse {current_horse.name}."

    def add_jockey_to_horse_race(self, race_type, jockey_name):
        jockey = self.get_jockey_by_name(jockey_name)
        horse_race = self.get_race_by_type(race_type)
        if not horse_race:
            raise Exception(f"Race {race_type} could not be found!")
        elif not jockey:
            raise Exception(f"Jockey {jockey_name} could not be found!")
        elif not jockey.horse:
            raise Exception(f"Jockey {jockey_name} cannot race without a horse!")
        elif jockey_name in [j.name for j in horse_race.jockeys]:
            return f"Jockey {jockey_name} has been already added to the {race_type} race."
        horse_race.jockeys.append(jockey)
        return f"Jockey {jockey_name} added to the {race_type} race."

    def start_horse_race(self, race_type):
        horse_race = self.get_race_by_type(race_type)
        if not horse_race:
            raise Exception(f"Race {race_type} could not be found!")
        participants = len(horse_race.jockeys)
        if participants < 2:
            raise Exception(f"Horse race {race_type} needs at least two participants!")
        jockeys_sorted_by_speed = [j for j in sorted(horse_race.jockeys, key=lambda jockey: -jockey.horse.speed)]
        winner = jockeys_sorted_by_speed[0]
        return f"The winner of the {race_type} race, with a speed of {winner.horse.speed}km/h is {winner.name}! Winner's horse: {winner.horse.name}."
