from abc import ABC, abstractmethod


class BaseAquarium(ABC):
    @abstractmethod
    def __init__(self, name, capacity):
        self.name = name
        self.capacity = capacity
        self.decorations = []
        self.fish = []

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        if not value:
            raise ValueError("Aquarium name cannot be an empty string.")
        self.__name = value

    def calculate_comfort(self):
        return sum([decoration.comfort for decoration in self.decorations])

    def add_fish(self, fish):
        if self.capacity == 0:
            return "Not enough capacity."
        elif type(self).__name__ != fish.SUITABLE_WATER:
            return "Water not suitable."
        self.fish.append(fish)
        self.capacity -= 1
        return f"Successfully added {type(fish).__name__} to {self.name}."

    def remove_fish(self, fish):
        self.fish.remove(fish)
        self.capacity += 1

    def add_decoration(self, decoration):
        self.decorations.append(decoration)

    def feed(self):
        for f in self.fish:
            f.eat()

    def __str__(self):
        res = f'{self.name}:\n'
        fish_names = [f.name for f in self.fish]
        if len(fish_names) == 0:
            fish_names = ['none']
        res += f'Fish: {" ".join(fish_names)}\n'
        res += f'Decorations: {len(self.decorations)}\n'
        res += f'Comfort: {self.calculate_comfort()}\n'
        return res