from project.fish.base_fish import BaseFish


class SaltwaterFish(BaseFish):
    SUITABLE_WATER = 'SaltwaterAquarium'

    def __init__(self, name, species, price):
        super().__init__(name, species, 5, price)
        self.size = 5

    def eat(self):
        self.size += 2