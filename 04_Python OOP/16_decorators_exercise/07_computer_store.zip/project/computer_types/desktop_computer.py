from project.computer_types.computer import Computer
from math import log2


class DesktopComputer(Computer):
    def __init__(self, manufacturer: str, model: str):
        super().__init__(manufacturer, model)
        self.viable_processors = {"AMD Ryzen 7 5700G": 500, "Intel Core i5-12600K": 600, "Apple M1 Max": 1800}

    def configure_computer(self, processor: str, ram: int):
        if processor not in self.viable_processors:
            raise ValueError(f"{processor} is not compatible with desktop computer {self.manufacturer} {self.model}!")
        if not self.is_power_of_two(ram) or ram > 128:
            raise ValueError(f"{ram}GB RAM is not compatible with desktop computer {self.manufacturer} {self.model}!")
        self.processor = processor
        self.ram = ram
        processor_price = self.viable_processors[processor]
        ram_price = int(log2(ram) * 100)
        self.price = processor_price + ram_price
        return f"Created {self.manufacturer} {self.model} with {processor} and {ram}GB RAM for {self.price}$."



