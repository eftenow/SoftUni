from unittest import TestCase, main

from project.student import Student


class StudentTests(TestCase):
    def test_student_init(self):
        student = Student('Ivan')
        self.assertEqual(student.name, 'Ivan')
        self.assertEqual(student.courses, {})

    def test_add_notes_to_already_existing_course(self):
        student = Student('Ivan')
        student.courses = {"Basic": ['note1', 'note2']}
        result = student.enroll('Basic', ['new_note'])
        self.assertEqual("Course already added. Notes have been updated.", result)
        self.assertIn('Basic', student.courses)
        self.assertEqual(['note1', 'note2', 'new_note'], student.courses['Basic'])

    def test_add_course_and_notes(self):
        student = Student('Ivan')
        result = student.enroll('Basic', 'This is easy', 'Y')
        self.assertEqual("Course and course notes have been added.", result)
        result = student.enroll('Fundamentals', 'This is not easy', "")
        self.assertEqual("Course and course notes have been added.", result)
        self.assertIn('Fundamentals', student.courses.keys())
        self.assertIn('Basic', student.courses.keys())
        self.assertIn('This is not easy', student.courses['Fundamentals'])


    def test_add_course(self):
        student = Student('Ivan')
        res = student.enroll('Basics', 'zzz', 'asd')
        self.assertEqual("Course has been added.", res)
        self.assertIn('Basics', student.courses.keys())
        self.assertEqual(student.courses['Basics'], [])

    def test_add_notes_to_non_existing_course_raises(self):
        student = Student('Ivan')
        with self.assertRaises(Exception) as ex:
            student.add_notes('Basic', 'asd')
        self.assertEqual("Cannot add notes. Course not found.", str(ex.exception))

    def test_add_notes_to_course(self):
        student = Student('Ivan', {'Basic': ["note1", 'note2']})
        res = student.add_notes('Basic', 'asd')
        self.assertEqual("Notes have been updated", res)
        self.assertEqual(["note1", 'note2', 'asd'], student.courses['Basic'])

    def test_leave_non_existing_course_raises(self):
        student = Student('Ivan')
        with self.assertRaises(Exception) as ex:
            student.leave_course('Basic')
        self.assertEqual("Cannot remove course. Course not found.", str(ex.exception))

    def test_leave_course(self):
        student = Student('Ivan', {'Basic': []})
        result = student.leave_course('Basic')
        self.assertEqual("Course has been removed", result)
        self.assertNotIn('Basic', student.courses.keys())


if __name__ == '__main__':
    main()