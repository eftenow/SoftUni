from unittest import TestCase, main

from project.vehicle import Vehicle


class VehicleTests(TestCase):
    def test_vehicle_init(self):
        vehicle = Vehicle(10, 100)
        self.assertEqual(vehicle.fuel, 10)
        self.assertEqual(vehicle.horse_power, 100)

    def test_drive_not_enough_fuel_returns(self):
        vehicle = Vehicle(5, 100)
        with self.assertRaises(Exception) as ex:
            vehicle.drive(5)
        self.assertEqual("Not enough fuel", str(ex.exception))

    def test_drive_enough_fuel(self):
        vehicle = Vehicle(20, 100)
        vehicle.drive(10)
        self.assertEqual(7.5, vehicle.fuel)

    def test_refuel_over_the_capacity_returns(self):
        vehicle = Vehicle(20, 100)
        with self.assertRaises(Exception) as ex:
            vehicle.refuel(10)
        self.assertEqual("Too much fuel", str(ex.exception))

    def test_refuel_with_valid_amount(self):
        vehicle = Vehicle(20, 100)
        vehicle.drive(10)
        vehicle.refuel(2.5)
        self.assertEqual(10, vehicle.fuel)

    def test_str_returns_correct_message(self):
        vehicle = Vehicle(20, 100)
        result = f"The vehicle has 100 " \
               f"horse power with 20 fuel left and {vehicle.fuel_consumption} fuel consumption"
        self.assertEqual(vehicle.__str__(), result)

if __name__ == '__main__':
    main()