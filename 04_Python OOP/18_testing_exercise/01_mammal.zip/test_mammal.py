from unittest import main, TestCase

from project.mammal import Mammal


class MammalTests(TestCase):
    def test_mammal_init(self):
        mammal = Mammal('mammal', 'type', 'bzz')
        self.assertEqual(mammal.name, 'mammal')
        self.assertEqual(mammal.type, 'type')
        self.assertEqual(mammal.sound, 'bzz')

    def test_mammal_makes_sound(self):
        mammal = Mammal('mammal', 'type', 'bzz')
        result = mammal.make_sound()
        self.assertEqual(result, 'mammal makes bzz')

    def test_return_kingdom(self):
        mammal = Mammal('mammal', 'type', 'bzz')
        mammal._Mammal__kingdom = 'asd'
        result = mammal.get_kingdom()
        self.assertEqual('asd', result)

    def test_info(self):
        mammal = Mammal('mammal', 'type', 'bzz')
        result = mammal.info()
        self.assertEqual('mammal is of type type', result)

if __name__ == "__main__":
    main()