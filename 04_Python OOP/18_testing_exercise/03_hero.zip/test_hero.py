from unittest import TestCase, main
from project.hero import Hero


class HeroTests(TestCase):

    def test_hero_init(self):
        hero = Hero('username', 20, 50, 50)
        self.assertEqual(hero.username, 'username')
        self.assertEqual(hero.level, 20)
        self.assertEqual(hero.damage, 50)
        self.assertEqual(hero.health, 50)

    def test_fight_against_oneself_raises(self):
        hero = Hero('username', 20, 50, 50)

        with self.assertRaises(Exception) as ex:
            hero.battle(hero)
        self.assertEqual(str(ex.exception), "You cannot fight yourself")

    def test_health_is_less_than_or_equal_to_zero_raises(self):
        enemy = Hero('enemy', 20, 5, 50)
        with self.assertRaises(ValueError) as ex:
            hero = Hero('username', 20, 0, 50)
            hero.battle(enemy)
        self.assertEqual(str(ex.exception), "Your health is lower than or equal to 0. You need to rest")
        with self.assertRaises(ValueError) as ex:
            hero = Hero('username', 20, -1, 50)
            hero.battle(enemy)
        self.assertEqual(str(ex.exception), "Your health is lower than or equal to 0. You need to rest")

    def test_enemy_health_is_less_than_or_equal_to_zero_raises(self):
        hero = Hero('username', 20, 10, 50)
        with self.assertRaises(ValueError) as ex:
            enemy = Hero('enemy', 20, 0, 50)
            hero.battle(enemy)
        self.assertEqual(str(ex.exception), f"You cannot fight {enemy.username}. He needs to rest")
        with self.assertRaises(ValueError) as ex:
            enemy = Hero('enemy', 20, -5, 50)
            hero.battle(enemy)
        self.assertEqual(str(ex.exception), f"You cannot fight {enemy.username}. He needs to rest")

    def test_battle_returns_you_lose_when_enemy_is_not_dead(self):
        user1 = Hero('username', 10, 100, 4)
        user2 = Hero('username2', 10, 100, 5)
        result = user1.battle(user2)

        self.assertEqual(50, user1.health)
        self.assertEqual(4, user1.damage)
        self.assertEqual(65, user2.health)
        self.assertEqual(10, user2.damage)
        self.assertEqual(11, user2.level)
        self.assertEqual(result, "You lose")

    def test_battle_returns_you_win_when_enemy_is_dead(self):
        user1 = Hero('username', 10, 100, 10)
        user2 = Hero('username2', 10, 100, 5)
        result = user1.battle(user2)

        self.assertEqual(user2.health, 0)
        self.assertEqual(user1.level, 11)
        self.assertEqual(user1.health, 55)
        self.assertEqual(user1.damage, 15)
        self.assertEqual(result, 'You win')

    def test_battle_returns_draw(self):
        user1 = Hero('username', 10, 100, 10)
        user2 = Hero('username2', 10, 100, 10)
        result = user1.battle(user2)
        self.assertEqual(user1.health, 0)
        self.assertEqual(user2.health, 0)
        self.assertEqual(result, 'Draw')

    def test_str_returns_correct_message(self):
        user1 = Hero('username', 10, 100, 10)
        result = f"Hero username: 10 lvl\n" \
        f"Health: 100\n" \
        f"Damage: 10\n"
        self.assertEqual(user1.__str__(), result)

if __name__ == '__main__':
    main()